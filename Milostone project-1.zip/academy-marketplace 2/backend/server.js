const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const bodyParser = require("body-parser");
const path = require("path");
const db = require("./db");

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "../public")));

app.use(session({
    secret: "secretkey",
    resave: false,
    saveUninitialized: false
}));

// Routes

// Register
app.post("/register", async (req, res) => {
    const { name, email, password } = req.body;

    const hashedPassword = await bcrypt.hash(password, 10);

    db.query(
        "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
        [name, email, hashedPassword],
        (err, result) => {
            if (err) {
                return res.send("User already exists!");
            }
            res.redirect("/login.html");
        }
    );
});

// Login
app.post("/login", (req, res) => {
    const { email, password } = req.body;

    db.query(
        "SELECT * FROM users WHERE email = ?",
        [email],
        async (err, results) => {
            if (results.length === 0) {
                return res.send("Invalid Email");
            }

            const user = results[0];
            const match = await bcrypt.compare(password, user.password);

            if (!match) {
                return res.send("Wrong Password");
            }

            req.session.user = user;
            res.redirect("/dashboard");
        }
    );
});

// Dashboard
app.get("/dashboard", (req, res) => {
    if (!req.session.user) {
        return res.redirect("/login.html");
    }

    db.query("SELECT * FROM courses", (err, results) => {
        let courseHTML = "";
        results.forEach(course => {
            courseHTML += `
                <div class="card">
                    <h3>${course.title}</h3>
                    <p>${course.description}</p>
                    <p>₹ ${course.price}</p>
                </div>
            `;
        });

        res.send(`
            <link rel="stylesheet" href="/css/style.css">
            <h2>Welcome to the Marketplace!</h2>
            ${courseHTML}
            <br><a href="/logout">Logout</a>
        `);
    });
});

// Logout
app.get("/logout", (req, res) => {
    req.session.destroy();
    res.redirect("/login.html");
});

app.listen(5000, () => {
    console.log("Server running at http://localhost:5000");
});