const mysql = require("mysql2");

// Create connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Midh@2006",   // 🔴 Replace with your MySQL password
  database: "academy"
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    console.error("❌ MySQL Connection Failed:", err.message);
  } else {
    console.log("✅ MySQL Connected Successfully");
  }
});

// Optional: handle connection errors later
db.on("error", (err) => {
  console.error("❌ MySQL Runtime Error:", err.message);
});

module.exports = db;